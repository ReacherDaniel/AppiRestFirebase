const { tasksCollection } = require('../models/task');

// Obtener todas las tareas
exports.getAllTasks = async (req, res) => {
    try {
        const snapshot = await tasksCollection.get();
        const tasks = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        res.status(200).json(tasks);
    } catch (error) {
        res.status(500).json({ message: "Error al obtener tareas", error });
    }
};

// Obtener tarea por ID
exports.getTaskById = async (req, res) => {
    try {
        const taskDoc = await tasksCollection.doc(req.params.id).get();
        if (!taskDoc.exists) {
            return res.status(404).json({ message: "Tarea no encontrada" });
        }
        res.status(200).json({ id: taskDoc.id, ...taskDoc.data() });
    } catch (error) {
        res.status(500).json({ message: "Error al obtener tarea", error });
    }
};

// Crear una nueva tarea con ID incremental
exports.createTask = async (req, res) => {
    try {
        // Obtener todas las tareas para calcular el ID
        const snapshot = await tasksCollection.get();
        const totalTasks = snapshot.size; // Cantidad de documentos en la colección
        
        // Definir un ID basado en la cantidad de tareas actuales
        const newTaskId = totalTasks + 1;

        const newTask = {
            id: newTaskId, // Asignar ID incremental
            title: req.body.title
        };

        // Guardar la tarea con el ID definido
        await tasksCollection.doc(String(newTaskId)).set(newTask);

        res.status(201).json(newTask);
    } catch (error) {
        res.status(500).json({ message: "Error al crear tarea", error });
    }
};

// Actualizar tarea por ID
exports.updateTask = async (req, res) => {
    try {
        const taskDoc = tasksCollection.doc(req.params.id);
        const taskSnapshot = await taskDoc.get();

        if (!taskSnapshot.exists) {
            return res.status(404).json({ message: "Tarea no encontrada" });
        }

        await taskDoc.update({ title: req.body.title });
        res.status(200).json({ id: req.params.id, title: req.body.title });
    } catch (error) {
        res.status(500).json({ message: "Error al actualizar tarea", error });
    }
};

// Eliminar una tarea por ID
exports.deleteTask = async (req, res) => {
    try {
        const taskDoc = tasksCollection.doc(req.params.id);
        const taskSnapshot = await taskDoc.get();

        if (!taskSnapshot.exists) {
            return res.status(404).json({ message: "Tarea no encontrada" });
        }

        await taskDoc.delete();
        res.status(200).json({ message: "Tarea eliminada correctamente" });
    } catch (error) {
        res.status(500).json({ message: "Error al eliminar tarea", error });
    }
};
