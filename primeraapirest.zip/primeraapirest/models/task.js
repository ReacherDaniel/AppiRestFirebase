const { db } = require('../firebase'); // Importar la conexión
const tasksCollection = db.collection('tasks');
module.exports = { tasksCollection };
