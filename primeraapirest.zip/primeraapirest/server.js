const { db } = require('./firebase');

async function testFirestore() {
    try {
        const docRef = db.collection('test').doc('sampleDoc');
        await docRef.set({ message: 'Firebase conectado correctamente' });
        console.log('CONEXION CON EXITO.');
    } catch (error) {
        console.error('Error al conectar con Firebase:', error);
    }
}

testFirestore();